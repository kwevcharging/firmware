#!/bin/sh

#upgrade lte firmware
killall network-manager
killall runkeeper

LTE_VER_R1_HW_SUB=01
LTE_VER_R2_HW_SUB=02

ELS31V_FIRMWARE_VERSION="4.3.3.0f"
ELS31V_FIRMWARE_FILENAME="ELS31-V_UE4.3.3.0f_arn40869.usf"

ELS61_US_FIRMWARE_A_REVERSION="00.026.00"
ELS61_US_FIRMWARE_FILENAME="els61-us_rev01.000_arn00.026.00.usf"
ELS61_US_UPDATE_TOOL=glinswup_BGS5_EHSx_PDSx_ELSx

ELS61_US_R2_FIRMWARE_A_REVERSION="01.000.01"
ELS61_US_R2_FIRMWARE_FILENAME="els61-us_rev02.013_arn01.000.01.usf"

LTE_FW_PATH="/mnt/config/ic/firmware/lte/"
LTE_VER_FILENAME="/mnt/config/ic/etc/lte-ver"

LTE_DEV0="/dev/ttyACM0"
LTE_DEV1="/dev/ttyACM1"
LTE_DEV2="/dev/ttyACM2"
LTE_DEV3="/dev/ttyACM3"
LTE_DEV4="/dev/ttyACM4"


do_normal_upgrade() {

    LTE_RET=""
    LTE_VER=""
    LTE_VEN=""

    i=0
    while [ "$LTE_VER" == "" ] || [ "$LTE_VEN" == "" ]; do
        echo "Reading LTE module version."
        LTE_RET=`/usr/bin/lteft -c ati1`
        LTE_VER=`echo "$LTE_RET" | grep REVISION | sed -n 1p | awk '{ print $3 }'`
        LTE_VEN=`echo "$LTE_RET" | grep ELS | awk '{ print $2 }'`
        LTE_AVER=`echo "$LTE_RET" | grep A-REVISION | sed -n 1p | awk '{ print $3 }'`

        HW_SUB=`echo $LTE_VER | cut -d '.' -f 1`
        FW_SUB=`echo $LTE_VER | cut -d '.' -f 2`

        echo "Your LTE REVISION = ${LTE_VER}"
        echo "Your LTE A-REVISON = ${LTE_AVER}"
        echo "Your LTE HW_SUB = ${HW_SUB} FW_SUB = ${FW_SUB}" 
        echo "Your LTE VENDOR = ${LTE_VEN}"

        echo "$LTE_RET" > $LTE_VER_FILENAME

        i=$(($i+1))
        if [ $i -ge 10 ]; then
            echo "Unknown LTE module."
            break
        fi
    done

    if [ -c $LTE_DEV0 ]; then
        if [ "$LTE_VEN" == "ELS31-V" ]; then
            if [ "$LTE_VER" == "$ELS31V_FIRMWARE_VERSION" ]; then
                echo "Your firmware is latest."
            else
                echo "You must upgrade LTE module firmware."
                if [ -f ${LTE_FW_PATH}glinswup_ELS31x ]; then
                    chmod +x ${LTE_FW_PATH}glinswup_ELS31x
                    ${LTE_FW_PATH}glinswup_ELS31x -p $LTE_DEV0 -f ${LTE_FW_PATH}/${ELS31V_FIRMWARE_FILENAME}
                else
                    echo "${LTE_FW_PATH}glinswup_ELS31x didn't exist"
                fi
            fi	
        else
            if [ "$LTE_VEN" == "ELS61-US" ]; then
                if [ "$HW_SUB" == "$LTE_VER_R1_HW_SUB" ]; then #R1
                    if [ "$LTE_AVER" == "$ELS61_US_FIRMWARE_A_REVERSION" ]; then
                        echo "Your firmware is latest."
                    else
                        echo "You must upgrade LTE module firmware."
                        if [ -f ${LTE_FW_PATH}${ELS61_US_UPDATE_TOOL} ]; then
                            chmod +x ${LTE_FW_PATH}${ELS61_US_UPDATE_TOOL}
                            ${LTE_FW_PATH}${ELS61_US_UPDATE_TOOL} -p $LTE_DEV0 -f ${LTE_FW_PATH}/${ELS61_US_FIRMWARE_FILENAME}
                        else
                            echo "${LTE_FW_PATH}${ELS61_US_UPDATE_TOOL} didn't exist"
                        fi
                    fi
                else
                    if [ "$HW_SUB" == "$LTE_VER_R2_HW_SUB" ]; then #R2
                        if [ "$LTE_AVER" == "$ELS61_US_R2_FIRMWARE_A_REVERSION" ]; then
                            echo "Your firmware is latest."
                        else
                            echo "You must upgrade LTE module firmware."
                            if [ -f ${LTE_FW_PATH}${ELS61_US_UPDATE_TOOL} ]; then
                                chmod +x ${LTE_FW_PATH}${ELS61_US_UPDATE_TOOL}
                                ${LTE_FW_PATH}${ELS61_US_UPDATE_TOOL} -p $LTE_DEV0 -f ${LTE_FW_PATH}/${ELS61_US_R2_FIRMWARE_FILENAME}
                            else
                                echo "${LTE_FW_PATH}${ELS61_US_UPDATE_TOOL} didn't exist"
                            fi
                        fi
                    else
                        echo "HW_SUB = $HW_SUB, it didn't match 01 or 02"
                    fi
                fi        
            else #not ELS31-V, not ELS61-US
                echo "You don't need to update LTE firmware."
            fi
        fi
    else
        echo "Your LTE module could not boot."
    fi
}

do_force_upgrade() {
    echo "do_force_upgrade..."
    if [ "$LTE_VEN" == "ELS31-V" ]; then
        echo "You must upgrade LTE module firmware."
        if [ -f ${LTE_FW_PATH}glinswup_ELS31x ]; then
            chmod +x ${LTE_FW_PATH}glinswup_ELS31x
            ${LTE_FW_PATH}glinswup_ELS31x -p $LTE_DEV0 -f ${LTE_FW_PATH}/${ELS31V_FIRMWARE_FILENAME}
        else
            echo "${LTE_FW_PATH}glinswup_ELS31x didn't exist"
        fi
    else
        if [ "$LTE_VEN" == "ELS61-US" ]; then
            if [ "$HW_SUB" == "$LTE_VER_R1_HW_SUB" ]; then #R1
                echo "You must upgrade LTE module firmware."
                if [ -f ${LTE_FW_PATH}${ELS61_US_UPDATE_TOOL} ]; then
                    chmod +x ${LTE_FW_PATH}${ELS61_US_UPDATE_TOOL}
                    ${LTE_FW_PATH}${ELS61_US_UPDATE_TOOL} -n -p $LTE_DEV0 -f ${LTE_FW_PATH}/${ELS61_US_FIRMWARE_FILENAME}
                else
                    echo "${LTE_FW_PATH}${ELS61_US_UPDATE_TOOL} didn't exist"
                fi
            else
                if [ "$HW_SUB" == "$LTE_VER_R2_HW_SUB" ]; then #R2
                    echo "You must upgrade LTE module firmware."
                    if [ -f ${LTE_FW_PATH}${ELS61_US_UPDATE_TOOL} ]; then
                        chmod +x ${LTE_FW_PATH}${ELS61_US_UPDATE_TOOL}
                        ${LTE_FW_PATH}${ELS61_US_UPDATE_TOOL} -n -p $LTE_DEV0 -f ${LTE_FW_PATH}/${ELS61_US_R2_FIRMWARE_FILENAME}
                    else
                        echo "${LTE_FW_PATH}${ELS61_US_UPDATE_TOOL} didn't exist"
                    fi
                else
                    echo "HW_SUB = $HW_SUB, it didn't match 01 or 02"
                fi
            fi        
        else #not ELS31-V, not ELS61-US
            echo "You don't need to update LTE firmware."
        fi
    fi
}

if [ -c $LTE_DEV0 ]; then
    echo "Found LTE module device."
else
    setmodempower on
    i=0
    while [ $i -le 30 ]; do
      sleep 1
      if [ -c $LTE_DEV0 ]; then
        echo "LTE device was activated."
        break
      else
        echo .
      fi
      i=$(($i+1))
    done
fi

sleep 3

echo "Cleaning error message..."
/usr/bin/lteft -c ati1 > /dev/null

if [ -c $LTE_DEV0 ]; then
    # LTE_DEV0 still exist
    do_normal_upgrade
else    
    echo "Your LTE module is gone"
    setmodempower off
    sleep 2
    setmodempower on
    i=0
    while [ $i -le 30 ]; do
        sleep 1
        if [ -c $LTE_DEV0 ]; then
            echo "LTE device was activated."
            break
        else
            echo .
        fi
        i=$(($i+1))
    done
    sleep 3

    # ------ check number of device node ------
    # for ELS61-US, it shall be /dev/ttyACM0 ~ /dev/ttyACM4
    #
    lte_normal_upgrade=0
    if [ -c $LTE_DEV0 ]; then
        if [ -c $LTE_DEV1 ]; then
            if [ -c $LTE_DEV2 ]; then
                if [ -c $LTE_DEV3 ]; then
                    if [ -c $LTE_DEV4 ]; then
                        lte_normal_upgrade=1
                    fi
                fi
            fi
        fi   
    fi
    echo "lte_normal_upgrade=$lte_normal_upgrade"
 
    if [ "$lte_normal_upgrade" == "1" ]; then
        do_normal_upgrade
    else
        # force upgrade
        echo "force upgrade..."
        if [ -f $LTE_VER_FILENAME ]; then
        echo "Reading LTE module version."
            LTE_RET=`cat $LTE_VER_FILENAME`
            LTE_VER=`echo "$LTE_RET" | grep REVISION | sed -n 1p | awk '{ print $3 }'`
            LTE_VEN=`echo "$LTE_RET" | grep ELS | awk '{ print $2 }'`
            LTE_AVER=`echo "$LTE_RET" | grep A-REVISION | sed -n 1p | awk '{ print $3 }'`

            HW_SUB=`echo $LTE_VER | cut -d '.' -f 1`
            FW_SUB=`echo $LTE_VER | cut -d '.' -f 2`

            echo "Your LTE REVISION = ${LTE_VER}"
            echo "Your LTE A-REVISON = ${LTE_AVER}"
            echo "Your LTE HW_SUB = ${HW_SUB} FW_SUB = ${FW_SUB}" 
            echo "Your LTE VENDOR = ${LTE_VEN}"

            do_force_upgrade
        else
            echo "ERROR: LTE module information didn't exist! "
        fi
    fi
fi   







    


