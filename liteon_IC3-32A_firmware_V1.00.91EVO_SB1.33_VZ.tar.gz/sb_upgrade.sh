#!/bin/sh

sb_firmware_path=/mnt/config/ic/firmware
SB_VERSION=1.33
retry=0

#upgrade Safety Board firmware
img_id=`shminfo SHOW CB | grep fw_image -A3 | awk  'NR==3 { print $8 }'`
sb_ver=`shminfo SHOW CBInst | grep version -A3 | awk  'NR==3 { print $4 }'`
sb_dev=`cat /sys/devices/virtual/tty/console/active`

production_date=$1
year=$(echo "$production_date" | cut -d- -f1)
week=$(echo "$production_date" | cut -d- -f2-)

do_sb_upgrade=1
if [ "$sb_dev" == "ttyS2" ]; then
    sb_port=0
else
    if [ "$sb_dev" == "ttyS0" ]; then
        sb_port=2
    else
        echo "wrong tty device for Safety Board"
        do_sb_upgrade=0
        exit 0;
    fi    
fi

# week number <= 20-28, ignore SB upugrade
if [ "$year" -lt 20 ]; then
    echo "ProductionDate: $production_date is earlier than 20-28"
    do_sb_upgrade=0
    exit 0;
else
    if [ "$year" -eq 20 ]; then
        if [ "$week" -le 28 ]; then
            echo "ProductionDate: $production_date is earlier than 20-28"
            do_sb_upgrade=0
            exit 0;
        fi
    fi
fi


if [ "$sb_ver" == "$SB_VERSION" ]; then
    do_sb_upgrade=0
    echo "No need upgrade. Safety Board firmware is $sb_ver"
    exit 0;
fi

while [ $retry -le 20 ]; do
    echo ""
    echo "img_id=$img_id sb_ver=$sb_ver sb_port=$sb_port"
    if [ "$do_sb_upgrade" == "1" ]; then
        echo "[***starting] $SB_VERSION upgrade ${retry}"
        
        shminfo nb_ready 0 > /dev/null ; sleep 2 ; \
        shminfo charger_ready 0 > /dev/null ; sleep 2 ; \
        shminfo Upgrade 1 > /dev/null ; shminfo close_com 0 > /dev/null ; shminfo trans_stop 0 > /dev/null ; sleep 1 ;
        shminfo Upgrade 0 > /dev/null ; shminfo close_com 0 > /dev/null ; shminfo trans_stop 0 > /dev/null ; sleep 1 ;
        shminfo Upgrade 0 > /dev/null ; shminfo close_com 1 > /dev/null ; shminfo trans_stop 1 > /dev/null ; sleep 1 ;
      
        echo "./ymodem -sy -p${sb_port} ${sb_firmware_path}/BBOX_${img_id}.bin"
        ./ymodem -sy -p${sb_port} ${sb_firmware_path}/BBOX_${img_id}.bin
        
        sleep 5 ;
        shminfo reset_evse 1 > /dev/null ; shminfo close_com 0 > /dev/null ; shminfo trans_stop 0 > /dev/null ; sleep 1;
        shminfo reset_evse 1 > /dev/null ; shminfo close_com 1 > /dev/null ; shminfo trans_stop 1 > /dev/null ; sleep 1;
        shminfo reset_evse 0 > /dev/null ; shminfo close_com 1 > /dev/null ; shminfo trans_stop 1 > /dev/null ; sleep 1;
        shminfo reset_evse 0 > /dev/null ; shminfo close_com 0 > /dev/null ; shminfo trans_stop 0 > /dev/null ; sleep 3;
        
        sb_ver=`shminfo SHOW CBInst | grep version -A3 | awk  'NR==3 { print $4 }'`
        echo "current sb version is $sb_ver"
    else
        echo "ignore sb upgrade"
    fi
    
    retry=$(($retry+1))
    if [ "$sb_ver" == "$SB_VERSION" ]; then
        exit 0;
    fi
done

exit 1;
